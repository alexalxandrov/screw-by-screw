from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE_DIR = ROOT / "content" / "models" / "ibm-pc-5150-1981"
sys.path.insert(0, str(ROOT / "tools" / "content"))

import validate_model_package as validator
import validate_glb_bindings as glb_bindings


class IBMPC5150ContentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.package = validator.load_package(PACKAGE_DIR)
        cls.model = cls.package["model"]
        cls.components_doc = cls.package["components"]
        cls.components = {item["id"]: item for item in cls.components_doc["components"]}
        cls.sources = {item["id"]: item for item in cls.package["sources"]["sources"]}
        cls.relationships = cls.package["relationships"]["relationships"]
        cls.claims = cls.package["claims"]["claims"]

    def test_official_content_package_validator_and_hashes_pass(self):
        report = validator.validate_package(self.package, PACKAGE_DIR)
        self.assertIn("Bilingual labels and semantic references: PASS", report)
        self.assertIn("Release manifest and SHA-256 integrity: PASS", report)
        self.assertIn("Accuracy status: illustrative proxy, not CAD", report)

    def test_launch_configuration_is_not_mixed_with_pc_xt_or_later_5150(self):
        self.assertEqual(self.model["configuration"]["era"], "August 1981 launch baseline")
        self.assertEqual(self.model["configuration"]["system_memory_kb"], 16)
        self.assertEqual(self.model["configuration"]["diskette_drives_installed"], 0)
        self.assertEqual(self.model["configuration"]["expansion_slots_total"], 5)
        self.assertEqual(self.model["specifications"]["memory"]["first_board_range_kb"], [16, 64])
        self.assertIn("IBM 5160 PC/XT", self.model["variant_notes"])
        self.assertEqual(self.model["geometry_status"], "illustrative_proxy_not_cad")

    def test_1981_psu_scope_is_120_vac_only_and_psu_remains_sealed(self):
        psu = self.model["specifications"]["power_supply"]
        self.assertEqual(psu["continuous_rating_w"], 63.5)
        self.assertEqual(psu["input_variants_vac"], [120])
        claim = next(item for item in self.claims if item["id"] == "claim.psu.input")
        self.assertEqual(claim["value"], "120 Vac")
        self.assertIn("120 Vac", self.components["psu.ac_inlet"]["description"]["en"])
        self.assertNotIn("220/240 Vac supply variant", self.components["psu.ac_inlet"]["description"]["en"])
        psu_remove = next(step for step in self.package["assembly_steps"]["steps"] if step["id"] == "step.psu.remove")
        self.assertIn("Do not open the PSU", psu_remove["safety_notes"]["en"])

    def test_canonical_inventory_counts_and_references(self):
        self.assertEqual(len(self.components), 71)
        self.assertEqual(len(self.relationships), 100)
        self.assertEqual(len(self.claims), 21)
        self.assertEqual(len(self.package["process_layers"]["process_layers"]), 5)
        self.assertEqual(len(self.package["learning"]["questions"]), 12)
        self.assertEqual(len(self.sources), 6)
        self.assertEqual(len({item["id"] for item in self.relationships}), 100)
        self.assertEqual(len({item["id"] for item in self.claims}), 21)


    def test_case_dimensions_are_scoped_to_one_secondary_museum_specimen(self):
        envelope = self.model["specifications"]["system_unit_envelope"]
        self.assertEqual((envelope["width_mm"], envelope["depth_mm"], envelope["height_mm"]), (494, 410, 140))
        self.assertEqual(envelope["evidence_status"], "secondary_catalog_data")
        self.assertIn("src.iser.fau.ibm5150.specimen_record_2025", self.sources)
        self.assertIn("one 1981", envelope["notes"])
        claim = next(item for item in self.claims if item["id"] == "claim.case.envelope.museum_specimen")
        self.assertEqual(claim["confidence_class"], "secondary_catalog_data")
        self.assertEqual(claim["value"], "494 × 410 × 140 mm (L × W × H)")

    def test_system_board_layout_uses_manufacturer_zones_not_claimed_coordinates(self):
        layout = self.model["specifications"]["system_board_layout_reference"]
        self.assertEqual(layout["evidence_status"], "manufacturer_data_for_relative_zones_only")
        self.assertIn("Fig. 4", layout["reference"])
        self.assertIn("not a dimensioned placement drawing", layout["notes"])
        self.assertEqual(layout["zones"]["expansion_slots"], "left-hand / upper-left board zone")

    def test_board_fastener_variance_is_not_applied_to_launch_baseline(self):
        board_screw = next(item for item in self.claims if item["id"] == "claim.board.screw")
        self.assertEqual(board_screw["value"], 1)
        self.assertEqual(board_screw["confidence_class"], "teardown_supported")
        self.assertIn("src.ibm.5150.hardware_maintenance_1981", board_screw["source_ids"])
        manual = self.sources["src.ibm.5150.hardware_maintenance_1981"]
        self.assertEqual(manual["url"], "https://minuszerodegrees.net/manuals/IBM/IBM_5150_Hardware_Maintenance_and_Service_6025072_AUG81.pdf")
        self.assertIn("6025072", manual["applicability"])
        self.assertNotIn("6025075", manual["applicability"])
        standoffs = self.components["case.chassis.board_standoffs"]
        self.assertEqual(standoffs["dimensions_status"], "unknown")
        self.assertIn("does not state their count", standoffs["description"]["en"])
        self.assertIn("src.pcworld.ibm5150.interior_2016", self.sources)
        self.assertIn("revision-unmatched", self.sources["src.pcworld.ibm5150.interior_2016"]["applicability"])

    def test_disassembly_is_a_source_backed_branching_graph_not_one_linear_teardown(self):
        doc = self.package["assembly_steps"]
        steps = doc["steps"]
        by_id = {step["id"]: step for step in steps}
        self.assertEqual(doc["status"], "partial_observed_sequence")
        self.assertIs(doc["complete_sequence"], False)
        self.assertEqual(len(steps), 14)
        self.assertEqual(len(doc["procedure_groups"]), 7)
        groups = {group["id"]: group for group in doc["procedure_groups"]}
        self.assertTrue(all(step.get("group_id") in groups for step in steps))
        self.assertTrue(all(step["id"] in groups[step["group_id"]]["step_ids"] for step in steps))
        self.assertTrue(all(step["source_ids"] for step in steps))
        self.assertTrue(all(set(step["source_ids"]) <= set(self.sources) for step in steps))
        # Dependencies must resolve and precede their dependents.
        for step in steps:
            for parent_id in step.get("prerequisite_step_ids", []):
                self.assertIn(parent_id, by_id)
                self.assertLess(by_id[parent_id]["sequence"], step["sequence"])
        # PSU, speaker and board removal remain independent FRU branches after cover opening.
        self.assertNotIn("step.psu.remove", by_id["step.board.remove"]["prerequisite_step_ids"])
        self.assertNotIn("step.speaker.remove", by_id["step.board.remove"]["prerequisite_step_ids"])
        self.assertIn("step.speaker.leads.disconnect", by_id["step.board.remove"]["prerequisite_step_ids"])
        # The manufacturer-documented board operation is retained exactly.
        board_slide = by_id["step.board.slide.release_standoffs"]["description"]["en"]
        self.assertIn("1/2 inch (12.7 mm)", board_slide)
        self.assertIn("away from the power supply", board_slide)
        # Optional diskette-drive/adapter operations stay conditional for the launch baseline.
        self.assertIn("no installed diskette drive", by_id["step.diskette.leads.disconnect"]["description"]["en"])
        self.assertIn("five empty slots", by_id["step.adapters.remove"]["description"]["en"])
        self.assertEqual(doc["replacement_procedures"]["status"], "source_bounded_fragments_not_a_complete_reassembly")
        self.assertEqual(
            {item["id"] for item in doc["replacement_procedures"]["procedures"]},
            {"replace.cover", "replace.option_adapters", "replace.power_supply", "replace.system_board"},
        )

    def test_service_motion_clips_are_separate_from_measured_geometry(self):
        clips = {clip["id"]: clip for clip in self.package["animations"]["clips"]}
        for clip_id in ("clip.ibm5150.cover.slide_demo", "clip.ibm5150.psu.remove_motion",
                        "clip.ibm5150.speaker.remove_motion", "clip.ibm5150.system_board.release_motion"):
            self.assertIn(clip_id, clips)
            self.assertEqual(clips[clip_id]["evidence_status"], "educational_approximation")
        board_clip = clips["clip.ibm5150.system_board.release_motion"]
        values = board_clip["tracks"][0]["keyframes"]
        self.assertEqual(values[1]["value"][0], 12.7)
        self.assertIn("final lift height and exact vector are illustrative", board_clip["description"]["en"])

    def test_every_component_is_bilingual_and_relationship_targets_exist(self):
        for component in self.components.values():
            self.assertTrue(component["name"]["en"].strip())
            self.assertTrue(component["name"]["ru"].strip())
            self.assertTrue(component["description"]["en"].strip())
            self.assertTrue(component["description"]["ru"].strip())
        for relation in self.relationships:
            self.assertIn(relation["from"], self.components)
            self.assertIn(relation["to"], self.components)
            self.assertTrue(set(relation["source_ids"]) <= set(self.sources))

    def test_content_hierarchy_is_bound_to_a_one_to_one_glb_node_tree(self):
        component_ids = list(self.components)
        node_index = {component_id: index for index, component_id in enumerate(component_ids)}
        nodes = [
            {"name": component_id, "extras": {"sbs_component_id": component_id}, "children": []}
            for component_id in component_ids
        ]
        scene_roots = []
        for component_id, component in self.components.items():
            parent_id = component.get("parent_id")
            if parent_id is None:
                scene_roots.append(node_index[component_id])
            else:
                nodes[node_index[parent_id]]["children"].append(node_index[component_id])
        result = glb_bindings.validate_bindings(
            self.components_doc,
            {"nodes": nodes, "scenes": [{"nodes": scene_roots}]},
        )
        self.assertIn("Every content component ID is present exactly once: PASS", result)
        self.assertIn("Content parent relationships are represented in GLB ancestry: PASS", result)


if __name__ == "__main__":
    unittest.main()
