from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PACKAGE_DIR = ROOT / "content" / "models" / "ibm-pc-5150-1981"
sys.path.insert(0, str(ROOT / "tools" / "content"))

import validate_model_package as validator
import validate_glb_bindings as glb_bindings


class IBMPC5150ContentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.package = validator.load_package(PACKAGE_DIR)
        cls.model = cls.package["model"]
        cls.components_doc = cls.package["components"]
        cls.components = {item["id"]: item for item in cls.components_doc["components"]}
        cls.sources = {item["id"]: item for item in cls.package["sources"]["sources"]}
        cls.relationships = cls.package["relationships"]["relationships"]
        cls.claims = cls.package["claims"]["claims"]

    def test_official_content_package_validator_and_hashes_pass(self):
        report = validator.validate_package(self.package, PACKAGE_DIR)
        self.assertIn("Bilingual labels and semantic references: PASS", report)
        self.assertIn("Release manifest and SHA-256 integrity: PASS", report)
        self.assertIn("Accuracy status: illustrative proxy, not CAD", report)

    def test_launch_configuration_is_not_mixed_with_pc_xt_or_later_5150(self):
        self.assertEqual(self.model["configuration"]["era"], "August 1981 launch baseline")
        self.assertEqual(self.model["configuration"]["system_memory_kb"], 16)
        self.assertEqual(self.model["configuration"]["diskette_drives_installed"], 0)
        self.assertEqual(self.model["configuration"]["expansion_slots_total"], 5)
        self.assertEqual(self.model["specifications"]["memory"]["first_board_range_kb"], [16, 64])
        self.assertIn("IBM 5160 PC/XT", self.model["variant_notes"])
        self.assertEqual(self.model["geometry_status"], "illustrative_proxy_not_cad")

    def test_1981_psu_scope_is_120_vac_only_and_psu_remains_sealed(self):
        psu = self.model["specifications"]["power_supply"]
        self.assertEqual(psu["continuous_rating_w"], 63.5)
        self.assertEqual(psu["input_variants_vac"], [120])
        claim = next(item for item in self.claims if item["id"] == "claim.psu.input")
        self.assertEqual(claim["value"], "120 Vac")
        self.assertIn("120 Vac", self.components["psu.ac_inlet"]["description"]["en"])
        self.assertNotIn("220/240 Vac supply variant", self.components["psu.ac_inlet"]["description"]["en"])
        self.assertIn("Do not open the PSU", self.package["assembly_steps"]["steps"][2]["safety_notes"]["en"])

    def test_canonical_inventory_counts_and_references(self):
        self.assertEqual(len(self.components), 71)
        self.assertEqual(len(self.relationships), 100)
        self.assertEqual(len(self.claims), 20)
        self.assertEqual(len(self.package["process_layers"]["process_layers"]), 5)
        self.assertEqual(len(self.package["learning"]["questions"]), 12)
        self.assertEqual(len(self.sources), 4)
        self.assertEqual(len({item["id"] for item in self.relationships}), 100)
        self.assertEqual(len({item["id"] for item in self.claims}), 20)

    def test_partial_service_sequence_is_never_presented_as_complete_teardown(self):
        steps = self.package["assembly_steps"]
        self.assertEqual(steps["status"], "partial_observed_sequence")
        self.assertIs(steps["complete_sequence"], False)
        self.assertEqual(len(steps["steps"]), 5)
        self.assertTrue(all(step["source_ids"] for step in steps["steps"]))
        self.assertTrue(all(set(step["source_ids"]) <= set(self.sources) for step in steps["steps"]))

    def test_every_component_is_bilingual_and_relationship_targets_exist(self):
        for component in self.components.values():
            self.assertTrue(component["name"]["en"].strip())
            self.assertTrue(component["name"]["ru"].strip())
            self.assertTrue(component["description"]["en"].strip())
            self.assertTrue(component["description"]["ru"].strip())
        for relation in self.relationships:
            self.assertIn(relation["from"], self.components)
            self.assertIn(relation["to"], self.components)
            self.assertTrue(set(relation["source_ids"]) <= set(self.sources))

    def test_content_hierarchy_is_bound_to_a_one_to_one_glb_node_tree(self):
        component_ids = list(self.components)
        node_index = {component_id: index for index, component_id in enumerate(component_ids)}
        nodes = [
            {"name": component_id, "extras": {"sbs_component_id": component_id}, "children": []}
            for component_id in component_ids
        ]
        scene_roots = []
        for component_id, component in self.components.items():
            parent_id = component.get("parent_id")
            if parent_id is None:
                scene_roots.append(node_index[component_id])
            else:
                nodes[node_index[parent_id]]["children"].append(node_index[component_id])
        result = glb_bindings.validate_bindings(
            self.components_doc,
            {"nodes": nodes, "scenes": [{"nodes": scene_roots}]},
        )
        self.assertIn("Every content component ID is present exactly once: PASS", result)
        self.assertIn("Content parent relationships are represented in GLB ancestry: PASS", result)


if __name__ == "__main__":
    unittest.main()
