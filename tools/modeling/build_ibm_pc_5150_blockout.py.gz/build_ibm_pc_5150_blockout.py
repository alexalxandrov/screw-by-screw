#!/usr/bin/env python3
"""Build an evidence-labelled IBM PC 5150 (1981) system-unit proxy scene.

Run from the repository root with Blender 4.3.2:
  blender --background --factory-startup --python-exit-code 1 \
    --python tools/modeling/build_ibm_pc_5150_blockout.py

The scene is a navigable educational blockout, not dimensionally complete CAD.
The outer enclosure envelope and component placements are visual proxies unless
explicitly described as source-backed in the companion content package.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import bpy
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[2]
MODEL_DIR = ROOT / "content/models/ibm-pc-5150-1981"
OUTPUT_DIR = ROOT / "MODELS/COMPUTERS/IBM/5150/04-WORKING/generated"
MODEL_ID = "computer.ibm.5150.1981"

# Proxy envelope in millimetres. It is deliberately not presented as an IBM
# measured chassis dimension; original case geometry requires a physical sample.
CASE_W, CASE_D, CASE_H = 494.0, 410.0, 140.0  # one FAU 1981 specimen envelope; secondary reference, not IBM-wide CAD
BOARD_W, BOARD_D = 215.9, 279.4  # 8.5 x 11 in, source-backed approximate board size


def parse_args():
    argv = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", default=str(OUTPUT_DIR))
    parser.add_argument("--no-glb", action="store_true")
    parser.add_argument("--no-blend", action="store_true")
    return parser.parse_args(argv)


def mat(name, color, metallic=0.0, roughness=0.72):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1.0)
    m.use_nodes = True
    bsdf = m.node_tree.nodes.get("Principled BSDF")
    if bsdf:
        bsdf.inputs["Base Color"].default_value = (*color, 1.0)
        bsdf.inputs["Metallic"].default_value = metallic
        bsdf.inputs["Roughness"].default_value = roughness
    return m


M = {
    "case": mat("Proxy | warm IBM-style painted metal", (0.66, 0.63, 0.54), 0.28),
    "case_dark": mat("Proxy | dark internal chassis", (0.23, 0.24, 0.23), 0.45),
    "cover_edge": mat("Proxy | cover edge", (0.48, 0.47, 0.42), 0.35),
    "steel": mat("Proxy | galvanized steel", (0.48, 0.52, 0.54), 0.78, 0.38),
    "standoff": mat("Proxy | dark polymer board standoffs", (0.13, 0.14, 0.13), 0.02, 0.86),
    "psu": mat("Proxy | PSU zinc enclosure", (0.48, 0.50, 0.48), 0.7, 0.42),
    "black": mat("Proxy | dark plastics", (0.075, 0.08, 0.075), 0.12),
    "pcb": mat("Proxy | green system-board substrate", (0.035, 0.22, 0.12), 0.05),
    "ic": mat("Proxy | DIP IC packages", (0.07, 0.075, 0.08), 0.08),
    "ceramic": mat("Proxy | ceramic / socket", (0.76, 0.75, 0.66), 0.05),
    "slot": mat("Proxy | expansion slot plastic", (0.69, 0.67, 0.53), 0.08),
    "copper": mat("Proxy | copper contact", (0.64, 0.31, 0.14), 0.7, 0.38),
    "rubber": mat("Proxy | rubber", (0.045, 0.047, 0.045), 0.0, 0.92),
    "label": mat("Proxy | dark faceplate details", (0.1, 0.1, 0.09), 0.15),
}


def box_mesh(name, dims, material, bevel=0.0):
    bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0))
    obj = bpy.context.object
    obj.name = name
    obj.dimensions = dims
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    obj.data.materials.append(material)
    if bevel > 0:
        mod = obj.modifiers.new("Soft blockout edges", "BEVEL")
        mod.width = bevel
        mod.segments = 2
        obj.modifiers.new("Weighted corner normals", "WEIGHTED_NORMAL")
    return obj


def cylinder_mesh(name, radius, depth, material, vertices=32, rotation=(0, 0, 0)):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices, radius=radius, depth=depth, location=(0, 0, 0), rotation=rotation)
    obj = bpy.context.object
    obj.name = name
    obj.data.materials.append(material)
    return obj


def move_local(obj, parent, loc, rot=(0, 0, 0)):
    obj.parent = parent
    obj.location = loc
    obj.rotation_euler = rot
    return obj


def create_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for collection in list(bpy.data.collections):
        if collection.name != "Collection":
            bpy.data.collections.remove(collection)
    scene = bpy.context.scene
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.scale_length = 0.001  # Blender coordinates treated as mm
    scene.render.engine = "BLENDER_EEVEE_NEXT"
    scene.render.resolution_x = 1400
    scene.render.resolution_y = 1000
    scene.render.resolution_percentage = 100
    scene.world.color = (0.055, 0.06, 0.065)

    collection = bpy.data.collections.new("Screw by Screw | IBM PC 5150")
    scene.collection.children.link(collection)
    return collection


def build():
    args = parse_args()
    components_doc = json.loads((MODEL_DIR / "components.json").read_text(encoding="utf-8"))
    components = components_doc["components"]
    ids = {item["id"] for item in components}
    if len(ids) != len(components):
        raise RuntimeError("Duplicate canonical component ID in components.json")

    collection = create_scene()
    # Every canonical content component receives exactly one empty glTF node.
    # Empty anchors keep evidence IDs independent from mesh detail and ensure
    # hierarchy/animation targets remain stable as visual geometry is refined.
    anchors = {}
    for item in components:
        anchor = bpy.data.objects.new(item["id"], None)
        anchor.empty_display_type = "PLAIN_AXES"
        anchor.empty_display_size = 2.5
        anchor["sbs_component_id"] = item["id"]
        anchor["sbs_model_id"] = MODEL_ID
        anchor["sbs_evidence_status"] = item.get("evidence_status", "illustrative")
        anchor["sbs_geometry_status"] = item.get("geometry_status", "proxy")
        collection.objects.link(anchor)
        anchors[item["id"]] = anchor
    for item in components:
        parent_id = item.get("parent_id")
        if parent_id:
            if parent_id not in anchors:
                raise RuntimeError(f"Unknown parent {parent_id} for {item['id']}")
            anchors[item["id"]].parent = anchors[parent_id]

    def box(cid, name, loc, dims, material, bevel=0.0, rot=(0, 0, 0)):
        if cid not in anchors:
            raise RuntimeError(f"Geometry references missing component ID: {cid}")
        obj = box_mesh(name, dims, material, bevel)
        move_local(obj, anchors[cid], loc, rot)
        return obj

    def cylinder(cid, name, loc, radius, depth, material, axis="Z", vertices=32):
        rot = (0, 0, 0) if axis == "Z" else ((math.pi / 2, 0, 0) if axis == "Y" else (0, math.pi / 2, 0))
        obj = cylinder_mesh(name, radius, depth, material, vertices, rot)
        move_local(obj, anchors[cid], loc)
        return obj

    def line(cid, name, points, radius, material):
        curve = bpy.data.curves.new(name, "CURVE")
        curve.dimensions = "3D"
        curve.bevel_depth = radius
        curve.bevel_resolution = 3
        spline = curve.splines.new("POLY")
        spline.points.add(len(points) - 1)
        for point, co in zip(spline.points, points):
            point.co = (*co, 1)
        obj = bpy.data.objects.new(name, curve)
        obj.data.materials.append(material)
        collection.objects.link(obj)
        obj.parent = anchors[cid]
        return obj

    def screw_slot(cid, loc, length=4.0, axis="Z"):
        # Purely visual slotted-head indicator. It does not encode a screw drive
        # standard, head diameter, thread, torque, or measured dimensions.
        x, y, z = loc
        if axis == "Y":
            return box(cid, "Slotted screw-head mark (proxy)",
                       (x, y + 2.8, z), (length, 0.65, 0.7), M["label"], 0.08)
        return box(cid, "Slotted screw-head mark (proxy)",
                   (x, y, z + 2.8), (length, 0.65, 0.7), M["label"], 0.08)

    # Chassis: base tray, rails and end panels. All envelope dimensions are
    # explicitly illustrative; details like folded seams and holes are omitted.
    box("case.chassis.base", "Chassis base-pan proxy", (0, 0, 28), (CASE_W, CASE_D, 2.2), M["case_dark"], 1.0)
    rail_x = CASE_W / 2 - 2.0
    panel_y = CASE_D / 2 - 2.0
    box("case.chassis.left_rail", "Left chassis rail proxy", (-rail_x, 0, 78), (4, CASE_D, 100), M["steel"], 1.0)
    box("case.chassis.right_rail", "Right chassis rail proxy", (rail_x, 0, 78), (4, CASE_D, 100), M["steel"], 1.0)
    box("case.chassis.front_panel", "Front internal panel proxy", (0, -panel_y, 82), (CASE_W - 4, 4, 112), M["case_dark"], 1.0)
    box("case.chassis.rear_panel", "Rear structure proxy", (0, panel_y, 82), (CASE_W - 4, 4, 112), M["case_dark"], 1.0)
    # IBM documents plural board standoffs and matching slots, but the cited
    # first-edition procedure does not state their count or exact coordinates.
    # Four visible markers below are deliberately illustrative placeholders.
    stand_off_proxy_points = ((-10, -112), (120, -112), (-10, 112), (120, 112))
    for x, y in stand_off_proxy_points:
        cylinder("case.chassis.board_standoffs", "Polymer board support marker (illustrative)",
                 (x, y, 40.7), 3.0, 13.0, M["standoff"], "Z", 16)
    for i, (x, y) in enumerate(((-205, -165), (205, -165), (-205, 165), (205, 165)), 1):
        box(f"case.chassis.foot.{i}", f"Rubber foot {i} proxy", (x, y, 16), (48, 40, 12), M["rubber"], 2.0)

    # Removable cover panels. Cover is a parent transform target for animations.
    box("case.cover.top", "Cover top panel proxy", (0, 0, CASE_H - 1.0), (CASE_W - 8, CASE_D - 8, 2.0), M["case"], 1.2)
    box("case.cover.left_skirt", "Cover left skirt proxy", (-CASE_W / 2 + 5, 0, 89), (2.0, CASE_D - 8, 102), M["case"], 0.6)
    box("case.cover.right_skirt", "Cover right skirt proxy", (CASE_W / 2 - 5, 0, 89), (2.0, CASE_D - 8, 102), M["case"], 0.6)
    for cid, x in (("fastener.cover.retaining.left", -205), ("fastener.cover.retaining.right", 205)):
        screw_loc = (x, 206, 132)
        cylinder(cid, "Rear cover retainer proxy", screw_loc, 3.0, 5.0, M["steel"], "Y", 20)
        screw_slot(cid, screw_loc, length=4.2, axis="Y")

    # Optional drive positions are visible as two empty bays; no mechanism is
    # added because the 1981 launch baseline had no installed disk drive.
    box("case.chassis.optional_drive_bay_a", "Empty optional drive bay A", (-155, -112, 91), (145, 178, 42), M["case_dark"], 1.0)
    box("case.chassis.optional_drive_bay_b", "Empty optional drive bay B", (-5, -112, 91), (145, 178, 42), M["case_dark"], 1.0)
    # Dark bay apertures emphasise their unpopulated status.
    box("case.chassis.optional_drive_bay_a", "Drive bay A opening", (-155, -202, 91), (138, 2, 35), M["black"], 0.5)
    box("case.chassis.optional_drive_bay_b", "Drive bay B opening", (-5, -202, 91), (138, 2, 35), M["black"], 0.5)

    # System PSU block at rear-right. The case is kept closed; no internals,
    # transformer/capacitor placement, or AC wiring is fabricated.
    psu_center = (-145, 112, 87)
    box("psu.enclosure", "PSU enclosure proxy (sealed)", psu_center, (174, 158, 98), M["psu"], 1.8)
    cylinder("psu.cooling_fan", "PSU cooling fan proxy", (-58, 112, 97), 34, 4, M["black"], "X", 40)
    # Radial vent slots: purely illustrative surface detail, parented to the fan object.
    for idx in range(12):
        angle = 2 * math.pi * idx / 12
        box("psu.vent_grille", "PSU vent slot proxy", (-57.5, 112 + math.cos(angle) * 27, 97 + math.sin(angle) * 27), (2, 3, 13), M["steel"], 0.4)
    box("psu.ac_inlet", "AC inlet proxy", (-145, 194, 80), (34, 3, 26), M["black"], 1.0)
    box("psu.power_switch", "Mains switch proxy", (-100, 194, 89), (18, 4, 12), M["black"], 1.0)
    # Harness and its connectors; routes are decorative and not wire/pin maps.
    line("psu.board_harness", "PSU harness route proxy", [(-65, 80, 83), (-20, 82, 70), (25, 95, 67)], 2.2, M["black"])
    box("psu.connector.p1", "PSU P1 connector proxy", (48, 96, 70), (18, 8, 8), M["black"], 0.8)
    box("psu.connector.p2", "PSU P2 connector proxy", (28, 96, 70), (18, 8, 8), M["black"], 0.8)
    box("psu.connector.diskette_a", "Optional diskette power lead A", (-15, 58, 64), (14, 8, 6), M["black"], 0.5)
    box("psu.connector.diskette_b", "Optional diskette power lead B", (-35, 58, 64), (14, 8, 6), M["black"], 0.5)
    for idx, (x, y) in enumerate(((-208, 175), (-82, 175), (-208, 50), (-82, 50)), 1):
        screw_loc = (x, y, 38)
        cid = f"fastener.psu.mount.{idx}"
        cylinder(cid, "PSU mounting screw proxy", screw_loc, 2.8, 5, M["steel"], "Z", 20)
        screw_slot(cid, screw_loc, length=4.0)

    # 1981 16KB–64KB motherboard family, with grouped RAM/ROM banks.
    board_z = 48.0
    box("board.pcb", "System-board PCB proxy", (55, 16, board_z), (BOARD_W, BOARD_D, 1.6), M["pcb"], 0.5)
    # Four dark slot marks visually pair with four proxy support markers. IBM's
    # procedure confirms slots/standoffs but does not publish their exact count,
    # shape, spacing or locations; these marks are not a measured hole pattern.
    for slot_index, (x, y) in enumerate(stand_off_proxy_points, 1):
        box("board.pcb", f"Board standoff slot marker {slot_index} (illustrative)",
            (x, y, board_z + 1.05), (10.0, 3.0, 0.7), M["label"], 0.35)
    # Board outline border is separate unlabelled visual trim and remains illustrative.
    for x in (-53, 163):
        box("board.pcb", "PCB edge detail", (x, 16, board_z + 1), (1.2, BOARD_D, 2), M["steel"])
    box("board.cpu.socket_8088", "8088 socket proxy", (7, 28, 56), (38, 42, 7), M["ceramic"], 1.0)
    box("board.cpu.intel_8088", "Intel 8088 package proxy", (7, 28, 60), (31, 35, 5), M["ic"], 0.8)
    # Optional coprocessor socket intentionally empty.
    box("board.cpu.socket_8087", "Optional 8087 socket proxy", (59, 28, 56), (38, 42, 7), M["ceramic"], 1.0)
    box("board.clock.oscillator", "Clock crystal can proxy", (-19, 114, 57), (20, 8, 8), M["steel"], 1.8)
    for cid, name, x, y in (
        ("board.chip.dma_8237a5", "8237A-5 DMA controller", 43, 102),
        ("board.chip.pic_8259a", "8259A interrupt controller", 87, 102),
        ("board.chip.pit_8253", "8253 timer", 129, 102),
        ("board.chip.ppi_8255a5", "8255A-5 peripheral interface", 138, 102),
        ("board.chip.clock_8284", "8284 clock generator", 120, 66),
    ):
        box(cid, name + " proxy", (x, y, 57), (22, 32, 5), M["ic"], 0.8)
    box("board.memory.ram_16kb", "Grouped 16KB RAM bank proxy", (-8, -48, 57), (78, 42, 5), M["ic"], 1.0)
    box("board.memory.rom_40kb", "Grouped 40KB ROM region proxy", (82, -48, 57), (76, 42, 5), M["ic"], 1.0)
    box("board.dip.sw1", "DIP switch block SW1 proxy", (145, -50, 57), (34, 10, 6), M["black"], 0.6)
    box("board.dip.sw2", "DIP switch block SW2 proxy", (145, -65, 57), (34, 10, 6), M["black"], 0.6)
    # Bus is a semantic assembly node; show a translucent-looking central rail.
    box("board.io_channel", "I/O channel spine proxy", (55, 75, 53), (190, 8, 2), M["copper"])
    slot_xs = (-15, 24, 63, 102, 141)
    for index, x in enumerate(slot_xs, 1):
        box(f"board.slot.j{index}", f"62-pin expansion socket J{index} proxy", (x, 132, 57), (34, 14, 12), M["slot"], 0.8)
        box(f"board.slot.j{index}", f"Slot contact bed J{index}", (x, 132, 64), (28, 1.4, 2), M["steel"])
    # Documented I/O connectors. Connector shell shape and exact footprint are proxies.
    for cid, name, x, y, size in (
        ("board.connector.cassette_j6", "Cassette J6", -33, -111, (16, 12, 8)),
        ("board.connector.keyboard_j7", "Keyboard J7", -7, -111, (18, 12, 8)),
        ("board.connector.power_p1", "Power P1", 32, -111, (22, 12, 8)),
        ("board.connector.power_p2", "Power P2", 62, -111, (22, 12, 8)),
        ("board.connector.speaker_p3", "Speaker P3", 107, -111, (18, 12, 8)),
        ("board.connector.cassette_p4", "Cassette P4 MIC/AUX", 142, -111, (18, 12, 8)),
    ):
        box(cid, name + " connector proxy", (x, y, 57), size, M["ceramic"], 0.7)
    # Functional interface blocks (logical components) have small neutral markers only.
    for cid, x in (("board.logic.keyboard_interface", -7), ("board.logic.cassette_interface", 57), ("board.logic.speaker_interface", 119)):
        box(cid, "Interface logic marker (not IC identification)", (x, -80, 55), (14, 14, 3), M["label"], 0.4)
    board_mount_loc = (147, -118, 53)
    cylinder("board.fastener.system_board_mount", "System-board retaining screw proxy", board_mount_loc, 2.8, 5, M["steel"], "Z", 20)
    screw_slot("board.fastener.system_board_mount", board_mount_loc, length=4.0)

    # Internal speaker and its documented two mounting screws.
    box("speaker.transducer", "Internal speaker transducer proxy", (170, -145, 48), (62, 40, 22), M["black"], 2.0)
    for idx, x in enumerate((147, 193), 1):
        screw_loc = (x, -145, 35)
        cid = f"fastener.speaker.mount.{idx}"
        cylinder(cid, "Speaker mounting screw proxy", screw_loc, 2.5, 5, M["steel"], "Z", 20)
        screw_slot(cid, screw_loc, length=3.6)

    # Scene staging: orthographic-ish isometric camera and soft studio lighting.
    bpy.ops.object.camera_add(location=(720, -850, 610))
    camera = bpy.context.object
    camera.name = "Presentation Camera"
    direction = Vector((0, 0, 70)) - camera.location
    camera.rotation_euler = direction.to_track_quat("-Z", "Y").to_euler()
    camera.data.type = "ORTHO"
    camera.data.ortho_scale = 790
    scene = bpy.context.scene
    scene.camera = camera
    camera.data.lens = 52

    bpy.ops.object.light_add(type="AREA", location=(120, -420, 650))
    key = bpy.context.object
    key.name = "Key softbox"
    key.data.energy = 1100
    key.data.shape = "DISK"
    key.data.size = 480
    key.rotation_euler = (math.radians(26), 0, math.radians(-14))
    bpy.ops.object.light_add(type="AREA", location=(-420, 120, 380))
    fill = bpy.context.object
    fill.name = "Fill softbox"
    fill.data.energy = 650
    fill.data.size = 420
    fill.rotation_euler = (math.radians(24), 0, math.radians(42))

    # Presentation-only objects are excluded from model semantics.
    for obj in (camera, key, fill):
        obj["sbs_export_role"] = "presentation_only"

    # Set a useful viewport angle and avoid accidental selection clutter.
    for area in bpy.context.screen.areas if bpy.context.screen else []:
        if area.type == "VIEW_3D":
            area.spaces.active.region_3d.view_distance = 730
            area.spaces.active.region_3d.view_location = (0, 0, 66)
            area.spaces.active.region_3d.view_rotation = camera.rotation_euler.to_quaternion()

    # Check every content ID is represented by exactly one canonical anchor.
    actual = [obj.get("sbs_component_id") for obj in collection.objects if obj.get("sbs_component_id")]
    if len(actual) != len(ids) or set(actual) != ids:
        raise RuntimeError(f"Canonical scene node coverage mismatch: {len(actual)} / {len(ids)}")

    OUTPUT_DIR_LOCAL = Path(args.output_dir).resolve()
    OUTPUT_DIR_LOCAL.mkdir(parents=True, exist_ok=True)
    blend_path = OUTPUT_DIR_LOCAL / "ibm_pc_5150_1981_blockout.blend"
    glb_path = OUTPUT_DIR_LOCAL / "ibm_pc_5150_1981.glb"
    manifest_path = OUTPUT_DIR_LOCAL / "ibm_pc_5150_1981.manifest.json"

    manifest = {
        "schema_version": "0.1.0",
        "model_id": MODEL_ID,
        "asset_type": "illustrative_blockout",
        "generator_version": "0.1.0",
        "geometry_status": "illustrative_proxy_not_cad",
        "units": "mm",
        "source_backed_dimensions": {"system_board_width_mm": BOARD_W, "system_board_depth_mm": BOARD_D},
        "specimen_reference_envelope_mm": {"width": CASE_W, "depth": CASE_D, "height": CASE_H,
                                             "source_id": "src.iser.fau.ibm5150.specimen_record_2025",
                                             "applicability": "one 1981 museum specimen; not an IBM-wide case specification"},
        "visual_proxy_envelope_mm": {"width": CASE_W, "depth": CASE_D, "height": CASE_H},
        "canonical_component_node_count": len(ids),
        "warnings": [
            "The 494 x 410 x 140 mm envelope is a secondary reference from one FAU 1981 specimen with CGA and memory expansion; it is not an IBM-wide case specification or a serial-matched launch measurement.",
            "IBM service documentation confirms plural motherboard standoffs and slots, but not their count or metric placement; four support/slot markers are illustrative display placeholders only.",
            "The first-edition IBM procedure identifies one system-board retaining screw. Do not substitute the two-screw/four-stand-off observation from a separate, revision-unmatched PCWorld specimen.",
            "Slotted head marks are visual proxies and do not establish fastener drive standard, dimensions, thread or torque.",
            "The original board's approximate 8.5 x 11 inch size is source-backed; board hole pattern and exact coordinates are not.",
            "No individual DRAM/ROM chip population or pin-level nets are asserted; memory is grouped by documented capacity.",
            "Optional 5.25-inch drive bays are empty in the 16KB no-drive launch baseline.",
            "The PSU enclosure is represented as a sealed service unit; hazardous internal mains circuitry is not modeled.",
            "Screw positions, dimensions, thread, torque and exact chassis sheet-metal geometry are unverified proxy geometry.",
            "The exploded views are presentation animations, not a measured disassembly sequence.",
        ],
    }
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    if not args.no_blend:
        bpy.ops.wm.save_as_mainfile(filepath=str(blend_path))
    if not args.no_glb:
        # GLB preserves the semantic hierarchy and per-object custom properties.
        bpy.ops.export_scene.gltf(
            filepath=str(glb_path),
            export_format="GLB",
            export_extras=True,
            export_apply=True,
            export_cameras=False,
            export_lights=False,
        )
    print(json.dumps({
        "model_id": MODEL_ID,
        "components": len(ids),
        "blend": str(blend_path) if not args.no_blend else None,
        "glb": str(glb_path) if not args.no_glb else None,
        "manifest": str(manifest_path),
        "geometry_status": "illustrative_proxy_not_cad",
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    build()
