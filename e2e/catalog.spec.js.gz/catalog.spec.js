import { test, expect } from "@playwright/test";

test("opens the offline model library and filters by exact manufacturer part number", async ({ page }) => {
  await page.goto("/");
  const open = page.locator("#catalog-open");
  await open.click();
  const dialog = page.locator("#model-catalog-dialog");
  await expect(dialog).toBeVisible();

  const card = page.locator('[data-model-id="gpu.evga.12g-p5-3655-kr"]');
  await expect(card).toBeVisible();
  await expect(card).toContainText("12G-P5-3655-KR");
  await expect(card).toContainText("Условная геометрия · не CAD");

  await page.locator("#catalog-search").fill("12g-p5-3655-kr");
  await expect(page.locator("#catalog-results .catalog-card")).toHaveCount(1);
  await page.locator("#catalog-category").selectOption("graphics_cards");
  await expect(page.locator("#catalog-results .catalog-card")).toHaveCount(1);

  await page.locator("#catalog-search").fill("no-such-device");
  await expect(page.locator("#catalog-results")).toContainText("Подходящих моделей не найдено");
  await page.keyboard.press("Escape");
  await expect(dialog).toBeHidden();
  await expect(open).toBeFocused();
});

test("catalog search is bilingual and retains the query when the UI language changes", async ({ page }) => {
  await page.goto("/");
  await page.locator("#catalog-open").click();
  await page.locator("#catalog-search").fill("видеокарты");
  await expect(page.locator("#catalog-results .catalog-card")).toHaveCount(1);

  await page.locator("#catalog-close").click();
  await page.locator("#language-toggle").click();
  await page.locator("#catalog-open").click();
  await expect(page.locator("#catalog-title")).toHaveText("MODEL LIBRARY");
  await expect(page.locator("#catalog-search")).toHaveValue("видеокарты");
  await expect(page.locator("#catalog-results .catalog-card")).toHaveCount(1);
});

test("opens the IBM PC 5150 1981 system-unit package from the offline catalogue", async ({ page }) => {
  await page.goto("/");
  await page.locator("#catalog-open").click();
  const card = page.locator('[data-model-id="computer.ibm.5150.1981"]');
  await expect(card).toBeVisible();
  await expect(card).toContainText("IBM");
  await expect(card).toContainText("5150");
  await expect(card).toContainText("16 КБ");
  await card.locator('[data-open-catalog-model="computer.ibm.5150.1981"]').click();
  await expect(page.locator("#app-status")).toContainText("Package validated · 71 components · 100 relationships");
  await expect(page.locator("#component-count")).toHaveText("71");
});
